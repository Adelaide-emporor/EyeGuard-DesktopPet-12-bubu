"""计时代理：护眼（20-20-20）与久坐提醒两套独立状态机。

两者共用同一个秒级 tick 与屏幕活跃度监控（ScreenActivityMonitor）：

护眼（活跃时间累加模型）：
- 仅在屏幕活跃（is_active）时递减剩余秒数；离开（锁屏/屏保/关屏/睡眠/
  会话断开/键鼠空闲）时冻结，恢复时按离开时长重置或继续。
- 手动暂停（托盘）同时暂停久坐提醒的累计。

久坐（屏幕在场时间累加模型）：
- 仅在“屏幕在场”（screen_present：未锁屏/无屏保/显示器开启/未睡眠/
  会话连接）时累计；键鼠空闲照常累计——看视频同样属于久坐。
- 进入任一离开状态即重置周期并撤销已弹出的提醒（离开=已经起身活动）。
- 到达间隔弹出“该起身了”，用户确认后进入站立倒计时（真实时间流逝，
  与屏幕状态无关），结束后提示“可以坐下了”并累计今日站立时长。
"""
from __future__ import annotations

from typing import Optional

from PySide6.QtCore import QObject, QTimer, Signal

from activity import (BIG_REASONS, AWAY_RESET_SECONDS, RESUME_GRACE_SECONDS,
                      REASON_TEXT, ScreenActivityMonitor)
from config import AppConfig, Stats
from utils import LOG, in_dnd

STATE_WORK = "work"      # 工作计时中
STATE_PAUSED = "paused"  # 已手动暂停
STATE_BREAK = "break"    # 休息提醒进行中

SED_TRACKING = "sed_tracking"      # 久坐计时中
SED_REMINDING = "sed_reminding"    # 起身提醒展示中（等待用户确认）
SED_STANDING = "sed_standing"      # 站立倒计时中

SNOOZE_MINUTES = 5  # 起身提醒“稍后再提醒”的推迟时长


class TimerAgent(QObject):
    """秒级 tick 驱动的双状态机（护眼 + 久坐）。

    对外信号：
        workTick(int)          护眼工作剩余秒数（托盘提示用）
        stateChanged(str)      护眼状态切换
        breakTriggered()       需要展示护眼休息提醒
        statsChanged()         护眼统计数字变化
        breakAutoFinished()    护眼休息期间检测到离开，主控制器应关闭休息窗口
        sedentaryTriggered()   久坐时间到，需要展示起身提醒
        sedentaryDismissed()   用户离开屏幕：撤销久坐提醒/坐下提示与排队
        standFinished(bool)    站立倒计时结束，参数为“用户是否在屏幕前”
        standCapReached(int)   今日站立累计达到设定上限，参数为今日分钟数
    """

    workTick = Signal(int)
    stateChanged = Signal(str)
    breakTriggered = Signal()
    statsChanged = Signal()
    breakAutoFinished = Signal()
    sedentaryTriggered = Signal()
    sedentaryDismissed = Signal()
    standFinished = Signal(bool)
    standCapReached = Signal(int)

    def __init__(self, cfg: AppConfig, stats: Stats,
                 parent: Optional[QObject] = None) -> None:
        super().__init__(parent)
        self._cfg = cfg
        self._stats = stats
        self._state = STATE_WORK
        self._remaining = cfg.work_minutes * 60  # 护眼剩余活跃秒数
        # 久坐状态机
        self._sed_state = SED_TRACKING
        self._sedentary_seconds = 0   # 本周期已连续久坐秒数
        self._stand_remaining = 0     # 站立倒计时剩余秒数
        self._stand_elapsed = 0       # 本次站立已进行秒数
        self._last_stand_seconds = 0  # 最近一次站立总时长（展示用）
        self._tick = QTimer(self)
        self._tick.setInterval(1000)
        self._tick.timeout.connect(self._on_tick)
        self._monitor = ScreenActivityMonitor(self)
        self._monitor.paused.connect(self.on_screen_paused)
        self._monitor.resumed.connect(self.on_screen_resumed)
        self.start_work_cycle()
        LOG.info("久坐提醒%s：每 %d 分钟提醒，站立 %d 分钟，每日上限 %d 分钟",
                 "已启用" if cfg.sedentary_enabled else "已关闭",
                 cfg.sedentary_interval_minutes, cfg.stand_minutes,
                 cfg.daily_stand_cap_minutes)

    # ---------------- 查询 ----------------
    @property
    def state(self) -> str:
        """护眼状态：work / paused / break。"""
        return self._state

    def remaining_seconds(self) -> int:
        """护眼当前工作周期剩余的活跃秒数。"""
        return max(0, int(self._remaining))

    @property
    def sedentary_state(self) -> str:
        """久坐状态：sed_tracking / sed_reminding / sed_standing。"""
        return self._sed_state

    @property
    def last_stand_seconds(self) -> int:
        """最近一次站立的实际时长（秒），用于“可以坐下了”文案。"""
        return self._last_stand_seconds

    # ---------------- 计时控制 ----------------
    def start_work_cycle(self, minutes: Optional[float] = None) -> None:
        """开始/重置一轮护眼工作计时；minutes 缺省用配置的工作时长。"""
        mins = self._cfg.work_minutes if minutes is None else minutes
        self._remaining = int(round(mins * 60))
        self._set_state(STATE_WORK)
        self._tick.start()
        self.workTick.emit(self.remaining_seconds())
        LOG.info("工作计时开始：活跃使用 %.1f 分钟后提醒休息", mins)

    def pause(self) -> None:
        """手动暂停计时（托盘菜单），同时暂停久坐累计；休息进行中忽略。"""
        if self._state in (STATE_PAUSED, STATE_BREAK):
            return
        self._set_state(STATE_PAUSED)
        LOG.info("计时已手动暂停（护眼与久坐累计同时暂停），剩余 %d 秒",
                 self.remaining_seconds())

    def resume(self) -> None:
        """手动恢复计时（仅暂停状态有效）。"""
        if self._state != STATE_PAUSED:
            return
        self._set_state(STATE_WORK)
        self.workTick.emit(self.remaining_seconds())
        LOG.info("计时已手动恢复")

    def toggle_pause(self) -> None:
        """托盘“暂停/恢复”菜单入口。"""
        if self._state == STATE_PAUSED:
            self.resume()
        else:
            self.pause()

    def reset(self) -> None:
        """重置为完整的最新工作周期。"""
        LOG.info("计时已重置")
        self.start_work_cycle()

    def set_config(self, cfg: AppConfig) -> None:
        """应用新配置：暂停态保持暂停但夹紧剩余时长；其余重启工作计时。"""
        self._cfg = cfg
        if self._state == STATE_PAUSED:
            self._remaining = min(self._remaining, cfg.work_minutes * 60)
        elif self._state != STATE_BREAK:
            self.start_work_cycle()
        # 久坐：参数变化后周期重新计时；进行中的站立不打断；关闭则全部撤销
        if not cfg.sedentary_enabled:
            self._sed_state = SED_TRACKING
            self._sedentary_seconds = 0
            self.sedentaryDismissed.emit()
        elif self._sed_state == SED_TRACKING:
            self._sedentary_seconds = 0
        LOG.info("新配置已应用到计时器（工作 %d 分钟 / 休息 %d 秒；久坐%s）",
                 cfg.work_minutes, cfg.break_seconds,
                 f"每 {cfg.sedentary_interval_minutes} 分钟" if
                 cfg.sedentary_enabled else "已关闭")

    # ---------------- 护眼流程 ----------------
    def trigger_break_now(self) -> None:
        """立即触发休息提醒（托盘“立即休息”或活跃时间用尽）。"""
        if self._state == STATE_BREAK:
            return
        self._set_state(STATE_BREAK)
        LOG.info("触发休息提醒")
        self.breakTriggered.emit()

    def _on_tick(self) -> None:
        """每秒回调：分别推进护眼与久坐两套逻辑。"""
        if (self._state == STATE_WORK and self._monitor.is_active):
            self._remaining -= 1
            self.workTick.emit(self.remaining_seconds())
            if self._remaining <= 0:
                self._on_work_finished()
        self._tick_sedentary()

    def _on_work_finished(self) -> None:
        """活跃时间用尽：免打扰则静默续期，否则触发休息。"""
        cfg = self._cfg
        if cfg.dnd_enabled and in_dnd(cfg.dnd_start, cfg.dnd_end):
            LOG.info("免打扰时段 %s-%s，本轮提醒静默跳过",
                     cfg.dnd_start, cfg.dnd_end)
            self.start_work_cycle()
            return
        self.trigger_break_now()

    def on_screen_paused(self, reason: str) -> None:
        """屏幕进入离开状态。"""
        text = REASON_TEXT.get(reason, reason)
        if self._state == STATE_BREAK:
            LOG.info("休息期间检测到离开（%s），视为已完成休息", text)
            self.breakAutoFinished.emit()
        elif self._state == STATE_WORK:
            LOG.info("屏幕未在使用（%s），工作计时暂停", text)
        if reason in BIG_REASONS:
            # 离开屏幕 = 已经起身活动：结束站立、撤销提醒并重置久坐周期
            self._reset_sedentary_by_away(text)

    def on_screen_resumed(self, away_seconds: float, big_state: bool) -> None:
        """回到屏幕：护眼按离开时长重置或继续；久坐周期在离开时已重置。"""
        if self._state != STATE_WORK:
            return  # 手动暂停或休息流程自行处理，屏幕事件不干扰
        if big_state or away_seconds > AWAY_RESET_SECONDS:
            LOG.info("离开 %.0f 秒%s，视为眼睛已休息，重置工作周期",
                     away_seconds,
                     "（经过锁屏/屏保/关屏/睡眠/会话断开）" if big_state else "")
            self.start_work_cycle()
        else:
            # 短暂空闲：继续剩余倒计时，但保底宽限，避免一回来就弹窗
            self._remaining = max(self._remaining, RESUME_GRACE_SECONDS)
            self.workTick.emit(self.remaining_seconds())
            LOG.info("短暂离开 %.0f 秒后恢复，继续计时（剩余 %d 秒）",
                     away_seconds, self._remaining)

    # ---------------- 由休息窗口/通知计时回叫 ----------------
    def on_break_done(self) -> None:
        """休息倒计时自然结束（或离开期间视为完成）。"""
        self._stats.record_break()
        self.statsChanged.emit()
        LOG.info("完成一次休息")
        self.start_work_cycle()

    def on_break_skipped(self) -> None:
        """用户跳过本次休息。"""
        self._stats.record_skip()
        self.statsChanged.emit()
        LOG.info("跳过一次休息")
        self.start_work_cycle()

    def on_break_postponed(self) -> None:
        """用户推迟休息：按推迟时长重新计一轮工作。"""
        self._stats.record_postpone()
        self.statsChanged.emit()
        LOG.info("推迟休息 %d 分钟", self._cfg.postpone_minutes)
        self.start_work_cycle(minutes=self._cfg.postpone_minutes)

    # ---------------- 久坐流程 ----------------
    def sedentary_confirmed(self) -> None:
        """用户在起身提醒中点击“已起身”：开始站立倒计时。"""
        if self._sed_state != SED_REMINDING:
            return
        self._sed_state = SED_STANDING
        self._stand_remaining = self._cfg.stand_minutes * 60
        self._stand_elapsed = 0
        LOG.info("用户确认已起身，开始 %d 分钟站立倒计时",
                 self._cfg.stand_minutes)

    def sedentary_snoozed(self, minutes: int = SNOOZE_MINUTES) -> None:
        """用户点击“稍后再提醒”：N 分钟后重新提醒。"""
        if self._sed_state != SED_REMINDING:
            return
        interval = self._cfg.sedentary_interval_minutes * 60
        self._sedentary_seconds = max(0, interval - minutes * 60)
        self._sed_state = SED_TRACKING
        LOG.info("久坐提醒推迟 %d 分钟", minutes)

    def _tick_sedentary(self) -> None:
        """每秒推进久坐状态机。"""
        if self._sed_state == SED_TRACKING:
            # 手动暂停不累计；键鼠空闲照常累计（看视频也属于久坐）
            if (self._state != STATE_PAUSED and self._cfg.sedentary_enabled
                    and self._monitor.screen_present):
                self._sedentary_seconds += 1
                if self._sedentary_seconds >= (
                        self._cfg.sedentary_interval_minutes * 60):
                    self._sed_state = SED_REMINDING
                    LOG.info("触发久坐提醒（已连续坐着 %d 分钟）",
                             self._cfg.sedentary_interval_minutes)
                    self.sedentaryTriggered.emit()
        elif self._sed_state == SED_STANDING:
            # 站立倒计时按真实时间流逝，与屏幕状态无关
            self._stand_remaining -= 1
            self._stand_elapsed += 1
            if self._stand_remaining <= 0:
                self._finish_stand()

    def _finish_stand(self) -> None:
        """站立倒计时结束：记账、检查每日上限并回到久坐跟踪。"""
        self._last_stand_seconds = self._stand_elapsed
        self._record_stand(self._stand_elapsed)
        self._sed_state = SED_TRACKING
        self._sedentary_seconds = 0
        present = self._monitor.screen_present
        LOG.info("站立活动结束（%d 秒），久坐周期重新开始",
                 self._last_stand_seconds)
        self.standFinished.emit(present)

    def _reset_sedentary_by_away(self, text: str) -> None:
        """用户离开屏幕：结束站立/撤销提醒并重置周期（离开=已起身活动）。"""
        if self._sed_state == SED_STANDING:
            LOG.info("离开屏幕结束站立（已站 %d 秒），计入今日站立活动",
                     self._stand_elapsed)
            self._record_stand(self._stand_elapsed)
        self._sed_state = SED_TRACKING
        self._sedentary_seconds = 0
        self.sedentaryDismissed.emit()

    def _record_stand(self, seconds: int) -> None:
        """累计今日站立时长；越过每日上限时给一次温和提示。"""
        if seconds <= 0:
            return
        self._stats.record_stand(seconds)
        cap = self._cfg.daily_stand_cap_minutes
        if (cap > 0 and not self._stats.stand_cap_notified
                and self._stats.stand_seconds >= cap * 60):
            self._stats.mark_stand_cap_notified()
            LOG.info("今日站立活动达到上限 %d 分钟", cap)
            self.standCapReached.emit(self._stats.stand_seconds // 60)

    # ---------------- 退出 ----------------
    def shutdown(self) -> None:
        """停止计时与屏幕监控（程序退出前调用）。"""
        self._tick.stop()
        self._monitor.shutdown()

    # ---------------- 内部 ----------------
    def _set_state(self, state: str) -> None:
        if self._state != state:
            self._state = state
            self.stateChanged.emit(state)
