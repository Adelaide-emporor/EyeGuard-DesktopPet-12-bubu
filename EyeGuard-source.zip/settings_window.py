"""设置窗口：全部可配置项 + 测试弹窗 + 保存/取消/恢复默认。"""
from __future__ import annotations

import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple

from PySide6.QtCore import Qt, QTime, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QFileDialog,
                               QTabWidget,
                               QFormLayout, QGroupBox, QHBoxLayout, QLabel,
                               QLineEdit, QMessageBox, QPlainTextEdit,
                               QPushButton, QSlider, QSpinBox, QTimeEdit,
                               QVBoxLayout, QWidget)

import autostart
from config import (MODE_FULLSCREEN, MODE_NOTIFICATION, MODE_PET, MODE_WINDOW,
                    AppConfig, save_config)
from utils import (SOUND_OPTIONS, build_app_icon, play_sound,
                   sound_custom_dir, sound_player)


class SettingsDialog(QDialog):
    """EyeGuard 设置对话框。

    信号：
        saved(object)    点击“保存”且写入成功后发出，携带新 AppConfig
        testPopup(object) 点击“测试弹窗”时发出，携带表单当前值构造的 AppConfig
    """

    saved = Signal(object)
    testPopup = Signal(object)
    testSedentary = Signal(object)
    testSit = Signal(object)
    characterChanged = Signal(str)

    def __init__(self, cfg: AppConfig,
                 characters: Optional[List[Tuple[str, str]]] = None,
                 parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self._characters = characters or []
        self.setWindowTitle("EyeGuard 设置")
        self.setWindowIcon(build_app_icon())
        self.setMinimumWidth(540)
        self._ready = False  # 装载表单期间不触发提示音试听
        self._build_ui()
        self._load(cfg)
        self._ready = True

    # ---------------- UI 构建 ----------------
    def _build_ui(self) -> None:
        self._work = QSpinBox(self)
        self._work.setRange(1, 240)
        self._work.setSuffix(" 分钟")

        self._break_sec = QSpinBox(self)
        self._break_sec.setRange(5, 600)
        self._break_sec.setSuffix(" 秒")

        self._postpone = QSpinBox(self)
        self._postpone.setRange(1, 120)
        self._postpone.setSuffix(" 分钟")

        self._title = QLineEdit(self)
        self._message = QPlainTextEdit(self)
        self._message.setFixedHeight(72)

        self._mode = QComboBox(self)
        self._mode.addItem("全屏置顶遮罩", MODE_FULLSCREEN)
        self._mode.addItem("普通窗口", MODE_WINDOW)
        self._mode.addItem("仅系统通知（托盘气泡）", MODE_NOTIFICATION)
        self._mode.addItem("桌宠眨眼（无弹窗）", MODE_PET)

        self._on_top = QCheckBox("普通窗口置顶显示", self)
        self._sound = QCheckBox("提醒时播放提示音", self)
        self._volume = QSlider(Qt.Orientation.Horizontal, self)
        self._volume.setRange(0, 100)
        self._volume.setValue(80)
        self._volume_label = QLabel("80%", self)
        self._volume_label.setMinimumWidth(40)
        self._volume.valueChanged.connect(self._on_volume_changed)
        volume_row = QHBoxLayout()
        volume_row.addWidget(self._volume)
        volume_row.addWidget(self._volume_label)
        self._eye_char = QComboBox(self)
        for folder, name in self._characters:
            self._eye_char.addItem(name, folder)
        self._eye_sound = QComboBox(self)
        for key, label in SOUND_OPTIONS:
            self._eye_sound.addItem(label, key)
        self._eye_sound.currentIndexChanged.connect(
            lambda _i: self._preview_sound(self._eye_sound))
        btn_import_eye = QPushButton("导入...", self)
        btn_import_eye.setToolTip("从本地选择 wav/mp3/m4a 作为护眼提醒音")
        btn_import_eye.clicked.connect(
            lambda: self._import_sound(self._eye_sound))
        eye_row = QHBoxLayout()
        eye_row.addWidget(self._eye_sound, 1)
        eye_row.addWidget(btn_import_eye)

        self._dnd_enabled = QCheckBox("启用免打扰时段", self)
        self._dnd_start = QTimeEdit(self)
        self._dnd_start.setDisplayFormat("HH:mm")
        self._dnd_end = QTimeEdit(self)
        self._dnd_end.setDisplayFormat("HH:mm")

        dnd_row = QHBoxLayout()
        dnd_row.addWidget(self._dnd_start)
        dnd_row.addWidget(QLabel("至", self))
        dnd_row.addWidget(self._dnd_end)
        dnd_row.addStretch(1)
        dnd_box = QGroupBox("免打扰（时段内到点不弹提醒，静默续期）", self)
        dnd_layout = QVBoxLayout(dnd_box)
        dnd_layout.addWidget(self._dnd_enabled)
        dnd_layout.addLayout(dnd_row)
        self._dnd_enabled.toggled.connect(self._sync_dnd)

        # ---- 久坐提醒 ----
        self._sed_enabled = QCheckBox(
            "启用久坐提醒（独立于护眼提醒计时）", self)
        self._sed_interval = QSpinBox(self)
        self._sed_interval.setRange(20, 60)
        self._sed_interval.setSuffix(" 分钟")
        self._sed_stand = QSpinBox(self)
        self._sed_stand.setRange(3, 10)
        self._sed_stand.setSuffix(" 分钟")
        self._sed_cap = QSpinBox(self)
        self._sed_cap.setRange(0, 600)
        self._sed_cap.setSuffix(" 分钟")
        self._sed_cap.setSpecialValueText("不提醒（0）")
        self._stand_sound = QComboBox(self)
        for key, label in SOUND_OPTIONS:
            self._stand_sound.addItem(label, key)
        self._stand_sound.currentIndexChanged.connect(
            lambda _i: self._preview_sound(self._stand_sound))
        btn_import_stand = QPushButton("导入...", self)
        btn_import_stand.setToolTip("从本地选择 wav/mp3/m4a 作为站立提醒音")
        btn_import_stand.clicked.connect(
            lambda: self._import_sound(self._stand_sound))
        stand_row = QHBoxLayout()
        stand_row.addWidget(self._stand_sound, 1)
        stand_row.addWidget(btn_import_stand)

        self._sit_sound = QComboBox(self)
        for key, label in SOUND_OPTIONS:
            self._sit_sound.addItem(label, key)
        self._sit_sound.currentIndexChanged.connect(
            lambda _i: self._preview_sound(self._sit_sound))
        btn_import_sit = QPushButton("导入...", self)
        btn_import_sit.setToolTip("从本地选择 wav/mp3/m4a 作为坐下提醒音")
        btn_import_sit.clicked.connect(
            lambda: self._import_sound(self._sit_sound))
        sit_row = QHBoxLayout()
        sit_row.addWidget(self._sit_sound, 1)
        sit_row.addWidget(btn_import_sit)

        # 站立/坐下各自独立选择桌宠角色
        self._stand_char = QComboBox(self)
        self._sit_char = QComboBox(self)
        for folder, name in self._characters:
            self._stand_char.addItem(name, folder)
            self._sit_char.addItem(name, folder)

        self._resident = QCheckBox(
            "桌宠常驻右下角待机（眨眼/呼吸动画，点击穿透）", self)

        sed_form = QFormLayout()
        sed_form.addRow("久坐提醒间隔", self._sed_interval)
        sed_form.addRow("站立活动时长", self._sed_stand)
        sed_form.addRow("每日站立上限", self._sed_cap)
        sed_form.addRow("站立提醒音", stand_row)
        sed_form.addRow("坐下提醒音", sit_row)
        sed_form.addRow("站立提醒角色", self._stand_char)
        sed_form.addRow("坐下提醒角色", self._sit_char)
        sed_box = QGroupBox("久坐提醒（建议每 30 分钟起身活动 3–10 分钟）", self)
        sed_layout = QVBoxLayout(sed_box)
        sed_layout.addWidget(self._sed_enabled)
        sed_layout.addLayout(sed_form)
        sed_layout.addWidget(self._resident)
        self._sed_enabled.toggled.connect(self._sync_sedentary)

        # ---- 桌宠名字与形象 ----
        self._pet_name = QLineEdit(self)
        self._pet_name.setMaxLength(12)
        self._pet_name.setPlaceholderText("夏cc")
        self._char_combo = QComboBox(self)
        for folder, name in self._characters:
            self._char_combo.addItem(name, folder)
        self._char_combo.currentIndexChanged.connect(
            self._on_character_changed)

        self._autostart = QCheckBox(
            "开机自动启动（写入注册表 HKCU\\...\\Run）", self)

        # ---- 选项卡布局：护眼提醒 / 久坐提醒 / 桌宠与通用 ----
        self._tabs = QTabWidget(self)

        eye_tab = QWidget()
        eye_form = QFormLayout(eye_tab)
        eye_form.addRow("工作时长", self._work)
        eye_form.addRow("休息时长", self._break_sec)
        eye_form.addRow("推迟时长", self._postpone)
        eye_form.addRow("弹窗标题", self._title)
        eye_form.addRow("弹窗正文", self._message)
        eye_form.addRow("提醒方式", self._mode)
        eye_form.addRow("", self._on_top)
        eye_form.addRow("", self._sound)
        eye_form.addRow("提示音音量", volume_row)
        eye_form.addRow("护眼提醒角色", self._eye_char)
        eye_form.addRow("护眼提醒音", eye_row)
        eye_form.addRow("", dnd_box)

        sed_tab = QWidget()
        sed_layout = QVBoxLayout(sed_tab)
        sed_layout.addWidget(sed_box)
        sed_layout.addStretch(1)

        general_tab = QWidget()
        general_form = QFormLayout(general_tab)
        general_form.addRow("桌宠名字", self._pet_name)
        general_form.addRow("桌宠形象", self._char_combo)
        general_form.addRow("", self._autostart)

        self._tabs.addTab(eye_tab, "护眼提醒")
        self._tabs.addTab(sed_tab, "久坐提醒")
        self._tabs.addTab(general_tab, "桌宠与通用")

        btn_test = QPushButton("测试护眼提醒", self)
        btn_test_sed = QPushButton("测试站立提醒", self)
        btn_test_sit = QPushButton("测试坐下提醒", self)
        btn_reset = QPushButton("恢复默认", self)
        btn_save = QPushButton("保存", self)
        btn_cancel = QPushButton("取消", self)
        btn_save.setDefault(True)
        btn_test.clicked.connect(self._on_test)
        btn_test_sed.clicked.connect(self._on_test_sedentary)
        btn_test_sit.clicked.connect(self._on_test_sit)
        btn_reset.clicked.connect(self._on_reset)
        btn_save.clicked.connect(self._on_save)
        btn_cancel.clicked.connect(self.reject)

        btn_row = QHBoxLayout()
        btn_row.addWidget(btn_test)
        btn_row.addWidget(btn_test_sed)
        btn_row.addWidget(btn_test_sit)
        btn_row.addWidget(btn_reset)
        btn_row.addStretch(1)
        btn_row.addWidget(btn_save)
        btn_row.addWidget(btn_cancel)

        root = QVBoxLayout(self)
        root.addWidget(self._tabs)   # 选项卡区域
        root.addLayout(btn_row)      # 底部按钮区固定，不随选项卡滚动

    # ---------------- 装载 / 收集 ----------------
    def _load(self, cfg: AppConfig) -> None:
        """把配置对象填充到表单（自启项以注册表实际状态为准）。"""
        self._work.setValue(cfg.work_minutes)
        self._break_sec.setValue(cfg.break_seconds)
        self._postpone.setValue(cfg.postpone_minutes)
        self._title.setText(cfg.popup_title)
        self._message.setPlainText(cfg.popup_message)
        index = self._mode.findData(cfg.popup_mode)
        self._mode.setCurrentIndex(max(0, index))
        self._on_top.setChecked(cfg.always_on_top)
        self._sound.setChecked(cfg.sound_enabled)
        self._dnd_enabled.setChecked(cfg.dnd_enabled)
        start = QTime.fromString(cfg.dnd_start, "HH:mm")
        end = QTime.fromString(cfg.dnd_end, "HH:mm")
        self._dnd_start.setTime(start if start.isValid() else QTime(22, 0))
        self._dnd_end.setTime(end if end.isValid() else QTime(7, 0))
        self._autostart.setChecked(autostart.is_enabled())
        self._volume.setValue(cfg.volume)
        self._volume_label.setText(f"{cfg.volume}%")
        self._ensure_item(self._eye_char, cfg.eye_character)
        self._ensure_sound_item(self._eye_sound, cfg.eye_sound)
        self._sed_enabled.setChecked(cfg.sedentary_enabled)
        self._sed_interval.setValue(cfg.sedentary_interval_minutes)
        self._sed_stand.setValue(cfg.stand_minutes)
        self._sed_cap.setValue(cfg.daily_stand_cap_minutes)
        self._ensure_item(self._stand_char, cfg.stand_character)
        self._ensure_item(self._sit_char, cfg.sit_character)
        self._ensure_sound_item(self._stand_sound, cfg.stand_sound)
        self._ensure_sound_item(self._sit_sound, cfg.sit_sound)
        self._resident.setChecked(cfg.resident_pet)
        self._pet_name.setText(cfg.pet_name)
        char_index = self._char_combo.findData(cfg.pet_character)
        self._char_combo.setCurrentIndex(max(0, char_index))
        self._sync_dnd()
        self._sync_sedentary()

    def _collect(self) -> AppConfig:
        """从表单收集一个经过校验的 AppConfig。"""
        cfg = AppConfig()
        cfg.work_minutes = self._work.value()
        cfg.break_seconds = self._break_sec.value()
        cfg.postpone_minutes = self._postpone.value()
        cfg.popup_title = self._title.text()
        cfg.popup_message = self._message.toPlainText()
        cfg.popup_mode = self._mode.currentData() or MODE_FULLSCREEN
        cfg.always_on_top = self._on_top.isChecked()
        cfg.sound_enabled = self._sound.isChecked()
        cfg.dnd_enabled = self._dnd_enabled.isChecked()
        cfg.dnd_start = self._dnd_start.time().toString("HH:mm")
        cfg.dnd_end = self._dnd_end.time().toString("HH:mm")
        cfg.autostart = self._autostart.isChecked()
        cfg.volume = self._volume.value()
        cfg.sedentary_enabled = self._sed_enabled.isChecked()
        cfg.sedentary_interval_minutes = self._sed_interval.value()
        cfg.stand_minutes = self._sed_stand.value()
        cfg.daily_stand_cap_minutes = self._sed_cap.value()
        cfg.stand_character = self._stand_char.currentData() or "yier"
        cfg.sit_character = self._sit_char.currentData() or "yier"
        cfg.stand_sound = self._stand_sound.currentData() or "pop"
        cfg.sit_sound = self._sit_sound.currentData() or "sparkle"
        cfg.eye_character = self._eye_char.currentData() or "yier"
        cfg.eye_sound = self._eye_sound.currentData() or "ding"
        cfg.pet_name = self._pet_name.text().strip() or "夏cc"
        if self._char_combo.currentData():
            cfg.pet_character = self._char_combo.currentData()
        cfg.resident_pet = self._resident.isChecked()
        return cfg.sanitized()

    def _sync_dnd(self) -> None:
        enabled = self._dnd_enabled.isChecked()
        self._dnd_start.setEnabled(enabled)
        self._dnd_end.setEnabled(enabled)

    def _sync_sedentary(self) -> None:
        enabled = self._sed_enabled.isChecked()
        self._sed_interval.setEnabled(enabled)
        self._sed_stand.setEnabled(enabled)
        self._sed_cap.setEnabled(enabled)
        self._stand_sound.setEnabled(enabled)
        self._sit_sound.setEnabled(enabled)
        self._stand_char.setEnabled(enabled)
        self._sit_char.setEnabled(enabled)
        self._resident.setEnabled(enabled)

    def _ensure_item(self, combo: QComboBox, folder: str) -> None:
        """确保角色组合框里存在指定包（配置里残留已删除包时补一项）。"""
        index = combo.findData(folder)
        if index < 0 and folder:
            combo.addItem(folder, folder)
            index = combo.count() - 1
        combo.setCurrentIndex(max(0, index))

    def _preview_sound(self, combo: QComboBox) -> None:
        """下拉选择即试听（装载表单期间不触发）。"""
        if self._ready:
            play_sound(combo.currentData())

    def _on_volume_changed(self, value: int) -> None:
        """音量滑块实时应用到播放器（默认 80，永不为 0；0 才是真正静音）。"""
        self._volume_label.setText(f"{value}%")
        sound_player().set_volume(value)

    def _ensure_sound_item(self, combo: QComboBox, key: str) -> None:
        """确保组合框里存在 key（自定义 file: 项按需补充）并选中。"""
        index = combo.findData(key)
        if index < 0 and key and key.startswith("file:"):
            combo.addItem(f"自定义：{Path(key[5:]).name}", key)
            index = combo.count() - 1
        combo.setCurrentIndex(max(0, index))

    def _import_sound(self, combo: QComboBox) -> None:
        """导入本地 wav/mp3/m4a 作为提醒音：复制到自定义目录并选中试听。"""
        path, _ = QFileDialog.getOpenFileName(
            self, "选择提示音文件", "",
            "音频文件 (*.wav *.mp3 *.m4a *.m3a *.aac)")
        if not path:
            return
        dest = sound_custom_dir() / (
            f"{datetime.now():%Y%m%d_%H%M%S}_{Path(path).name}")
        try:
            shutil.copyfile(path, dest)
        except OSError as exc:
            QMessageBox.warning(self, "EyeGuard", f"导入失败：{exc}")
            return
        key = "file:" + str(dest)
        existing = combo.findData(key)
        if existing >= 0:
            combo.setCurrentIndex(existing)
            return
        combo.addItem(f"自定义：{dest.name}", key)
        combo.setCurrentIndex(combo.count() - 1)

    def _on_character_changed(self, index: int) -> None:
        """切换桌宠形象：立即生效并由主窗口自动保存。"""
        if self._ready and 0 <= index < self._char_combo.count():
            folder = self._char_combo.itemData(index)
            if folder:
                self.characterChanged.emit(str(folder))

    # ---------------- 动作 ----------------
    def _on_test(self) -> None:
        """用当前表单值弹一次测试窗口（不保存、不计入统计、不影响计时）。"""
        self.testPopup.emit(self._collect())

    def _on_test_sedentary(self) -> None:
        """用当前表单值弹一次站立提醒测试（桌宠 + 音效）。"""
        self.testSedentary.emit(self._collect())

    def _on_test_sit(self) -> None:
        """用当前表单值弹一次坐下提醒测试（桌宠 + 音效）。"""
        self.testSit.emit(self._collect())

    def _on_reset(self) -> None:
        """把表单恢复为出厂默认值（未保存前不生效）。"""
        self._load(AppConfig())

    def _on_save(self) -> None:
        """保存配置 + 同步注册表自启，然后发出 saved 并关闭。"""
        cfg = self._collect()
        if not save_config(cfg):
            QMessageBox.warning(
                self, "EyeGuard", "配置保存失败，请检查磁盘权限或查看日志。")
            return
        if not autostart.set_enabled(cfg.autostart):
            QMessageBox.warning(
                self, "EyeGuard", "开机自启写入注册表失败，请查看日志。")
        self.saved.emit(cfg)
        self.accept()
