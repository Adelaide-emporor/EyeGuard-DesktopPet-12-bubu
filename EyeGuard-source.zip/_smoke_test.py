"""EyeGuard 冒烟测试 v7（项目常驻）。

覆盖：护眼/久坐计时回归、原图角色包、三类桌宠窗口、单实例调度、
托盘菜单顺序、三路提示音。
数据目录重定向到项目内 .smoke_tmp；offscreen 模式运行，不弹任何窗口。
用法：python _smoke_test.py
"""
from __future__ import annotations

import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

# 环境重定向必须在导入项目模块之前完成
_HERE = Path(__file__).resolve().parent
os.environ["APPDATA"] = str(_HERE / ".smoke_tmp")
os.environ["QT_QPA_PLATFORM"] = "offscreen"

from PySide6.QtCore import QRect  # noqa: E402
from PySide6.QtTest import QTest  # noqa: E402
from PySide6.QtWidgets import QApplication, QPushButton  # noqa: E402

app = QApplication.instance() or QApplication(sys.argv)

import main  # noqa: E402
from activity import (AWAY_RESET_SECONDS, REASON_IDLE, REASON_LOCK)  # noqa: E402
from character import CharacterManager  # noqa: E402
from config import (MODE_PET, AppConfig, Stats, load_config,  # noqa: E402
                    load_stats)
from break_window import BreakWindow  # noqa: E402
from pet_window import (EyeBreakPetWindow, ResidentPetWindow,  # noqa: E402
                        SedentaryPetWindow, SitDownPetWindow)
from timer_agent import (SED_REMINDING, SED_STANDING, SED_TRACKING,  # noqa: E402
                         STATE_BREAK, STATE_PAUSED, STATE_WORK, TimerAgent)
from tray import TrayController  # noqa: E402
from utils import (build_app_icon, ensure_sound_files,  # noqa: E402
                   is_valid_sound, play_sound, sound_dir, sound_player,
                   verify_audio_resources)

FAILURES: list = []


def check(name: str, ok: bool) -> None:
    print(f"{'PASS' if ok else 'FAIL'}  {name}", flush=True)
    if not ok:
        FAILURES.append(name)


def make_agent(cfg: AppConfig) -> tuple:
    """创建代理并屏蔽真实系统轮询/空闲，保证测试确定性。"""
    agent = TimerAgent(cfg, Stats())
    monitor = agent._monitor
    monitor.idle_seconds = lambda: 0.0
    monitor._poll_screensaver = lambda: None
    monitor._poll_lock_fallback = lambda: None
    monitor._poll_idle = lambda: None
    return agent, monitor


FULL = AppConfig().work_minutes * 60

# ================= 护眼回归 =================
agent, monitor = make_agent(AppConfig())
paused_events: list = []
resumed_events: list = []
monitor.paused.connect(lambda r: paused_events.append(r))
monitor.resumed.connect(lambda a, b: resumed_events.append((a, b)))

r0 = agent.remaining_seconds()
QTest.qWait(2300)
check("活跃时倒计时递减", agent.remaining_seconds() <= r0 - 2)

monitor._apply_flag(REASON_LOCK, True)
check("锁屏后视为离开", not monitor.is_active and paused_events == [REASON_LOCK])
frozen = agent.remaining_seconds()
QTest.qWait(2300)
check("离开期间计时不增加", agent.remaining_seconds() == frozen)

monitor._apply_flag(REASON_LOCK, False)
check("解锁后重置为完整周期", agent.remaining_seconds() == FULL
      and resumed_events and resumed_events[-1][1] is True)

agent._remaining = 10
monitor._apply_flag(REASON_IDLE, True)
QTest.qWait(1300)
monitor._apply_flag(REASON_IDLE, False)
check("短暂空闲恢复继续且宽限到 60 秒",
      agent.remaining_seconds() >= 60 and resumed_events[-1][1] is False)

agent._remaining = 300
monitor._apply_flag(REASON_IDLE, True)
monitor._absence_start = datetime.now() - timedelta(
    seconds=AWAY_RESET_SECONDS + 30)
monitor._apply_flag(REASON_IDLE, False)
check("空闲超过 1 分钟重置周期", agent.remaining_seconds() == FULL)

auto: list = []
agent.breakAutoFinished.connect(lambda: auto.append(1))
agent.trigger_break_now()
check("进入休息状态", agent.state == STATE_BREAK)
monitor._apply_flag(REASON_LOCK, True)
agent.on_break_done()
check("离开自动结束休息并记账",
      auto == [1] and agent.state == STATE_WORK and agent._stats.breaks == 1)
monitor._apply_flag(REASON_LOCK, False)

agent.pause()
agent._remaining = 500
monitor._apply_flag(REASON_LOCK, True)
monitor._apply_flag(REASON_LOCK, False)
check("手动暂停期间屏幕事件不重置", agent.state == STATE_PAUSED
      and agent.remaining_seconds() == 500)
agent.resume()

dnd_agent, _ = make_agent(AppConfig(
    dnd_enabled=True,
    dnd_start=(datetime.now() - timedelta(minutes=1)).strftime("%H:%M"),
    dnd_end=(datetime.now() + timedelta(minutes=1)).strftime("%H:%M")))
dnd_agent._remaining = 1
dnd_agent._on_work_finished()
check("免打扰静默续期", dnd_agent.state == STATE_WORK)
dnd_agent.shutdown()

agent.shutdown()
check("TrayController 具备 hide()（退出路径回归）",
      hasattr(TrayController, "hide"))
check("main 模块可导入", hasattr(main, "main"))

# ================= 久坐提醒 =================
sed_agent, sed_mon = make_agent(AppConfig(sedentary_enabled=True))
sed_events = {"triggered": 0, "dismissed": 0, "stand": [], "cap": []}
sed_agent.sedentaryTriggered.connect(
    lambda: sed_events.__setitem__("triggered", sed_events["triggered"] + 1))
sed_agent.sedentaryDismissed.connect(
    lambda: sed_events.__setitem__("dismissed", sed_events["dismissed"] + 1))
sed_agent.standFinished.connect(lambda p: sed_events["stand"].append(p))
sed_agent.standCapReached.connect(lambda m: sed_events["cap"].append(m))

sed_agent._sedentary_seconds = sed_agent._cfg.sedentary_interval_minutes * 60 - 2
QTest.qWait(3400)
check("久坐达到间隔触发提醒", sed_events["triggered"] == 1
      and sed_agent.sedentary_state == SED_REMINDING)

sed_agent.sedentary_confirmed()  # confirm 后再缩短倒计时便于测试
sed_agent._stand_remaining = 3
sed_agent._stand_elapsed = 0
QTest.qWait(4600)
check("站立结束记账并回到跟踪态",
      sed_events["stand"] == [True] and sed_agent.sedentary_state == SED_TRACKING
      and sed_agent._stats.stand_seconds >= 3)

sed_agent._sedentary_seconds = 900
sed_mon._apply_flag(REASON_LOCK, True)
check("锁屏重置久坐周期并撤销提醒",
      sed_agent._sedentary_seconds == 0 and sed_events["dismissed"] == 1)
sed_mon._apply_flag(REASON_LOCK, False)

sed_agent._sedentary_seconds = 900
sed_mon._apply_flag(REASON_IDLE, True)
check("键鼠空闲不重置久坐", sed_agent._sedentary_seconds == 900)
sed_mon._apply_flag(REASON_IDLE, False)

sed_agent.shutdown()

# ================= 角色包系统（原图抠像 single 型） =================
ensure_sound_files()
manager = CharacterManager()
packs = manager.packs()
check("角色包扫描到一二与布布", "yier" in packs and "bubu" in packs)
check("角色包显示名正确", packs["yier"].name == "一二"
      and packs["bubu"].name == "布布")
check("角色包为 single 单图型且素材已加载",
      all(pack.kind == "single" and pack.image is not None
          and not pack.image.isNull() for pack in packs.values()))
check("原图素材为透明 PNG 且尺寸合理", all(
      pack.image.hasAlphaChannel() and pack.image.width() > 100
      and pack.image.height() > 100 for pack in packs.values()))
check("五个动作动画参数齐全", all(
      all(s in pack.animations
          for s in ("idle", "wave", "jump", "happy", "sit"))
      for pack in packs.values()))
check("模板目录不被加载", "example" not in packs)
check("回退默认角色", manager.get("不存在的包") is packs["yier"])

# ================= 桌宠窗口 =================
yier = packs["yier"]
sed_win_events: list = []
sed_win = SedentaryPetWindow(yier, is_test=True)
sed_win.confirmed.connect(lambda: sed_win_events.append("confirmed"))
sed_win.snoozed.connect(lambda: sed_win_events.append("snoozed"))
sed_win.start()
QTest.qWait(80)
sed_win.confirm()
sed_win.confirm()
check("起身提醒桌宠确认信号只发一次", sed_win_events == ["confirmed"])
QTest.qWait(int(yier.duration_ms("happy")) + 300)

sit_win = SitDownPetWindow(packs["bubu"], 305, is_test=True)
sit_win.start()
QTest.qWait(60)
check("坐下提示桌宠可创建显示", sit_win.isVisible())
sit_win.close()

eye_win = EyeBreakPetWindow(yier, message="请看向 20 英尺（约 6 米）外，放松眼睛 20 秒",
                            countdown_seconds=20, postpone_minutes=5,
                            is_test=True, auto_close_ms=3000)
eye_win.start()
QTest.qWait(1300)
check("护眼眨眼桌宠显示且气泡含台词与倒计时",
      eye_win.isVisible() and eye_win._current_state() == "blink"
      and "秒后继续工作" in eye_win._bubble._message.text())
check("护眼桌宠气泡含跳过与推迟按钮",
      eye_win._bubble._message.text() is not None
      and any("跳过休息" in b.text() for b in eye_win._bubble.findChildren(QPushButton)))
skip_events: list = []
postpone_events: list = []
eye_win2 = EyeBreakPetWindow(yier, is_test=True, auto_close_ms=3000)
eye_win2.skipClicked.connect(lambda: skip_events.append("skip"))
eye_win2.postponeClicked.connect(lambda: postpone_events.append("postpone"))
eye_win2.start()
QTest.qWait(60)
eye_win2._skip_break()
eye_win2._skip_break()
check("双击/跳过只发一次信号且窗口关闭",
      skip_events == ["skip"] and postpone_events == []
      and not eye_win2.isVisible())
QTest.qWait(150)  # 等工作线程处理停止指令
check("跳过后音效停止指令已提交", sound_player()._command == ("stop", None)
      or sound_player()._command is None)
eye_win3 = EyeBreakPetWindow(yier, is_test=True, auto_close_ms=3000)
postpone_events2: list = []
eye_win3.postponeClicked.connect(lambda: postpone_events2.append(1))
eye_win3.start()
QTest.qWait(60)
eye_win3._eye_snooze()
check("推迟按钮发出推迟信号", postpone_events2 == [1]
      and not eye_win3.isVisible())
eye_win2.deleteLater(); eye_win3.deleteLater()
check("坐下提醒测试入口存在", hasattr(main.EyeGuardApp, "show_sit_reminder"))

# ================= 遮罩/窗口预览单实例（防叠加） =================
from config import MODE_WINDOW  # noqa: E402
mask_events: list = []
mask1 = BreakWindow(AppConfig(popup_mode=MODE_WINDOW), is_test=True)
mask1.skipped.connect(lambda: mask_events.append("skipped"))
mask1.start()
QTest.qWait(60)
mask2 = BreakWindow(AppConfig(popup_mode=MODE_WINDOW), is_test=True)
mask2.start()
QTest.qWait(60)
mask1.dismiss_quietly()  # 主程序调度：新遮罩出现前静默关闭旧遮罩
QTest.qWait(60)
check("遮罩预览旧窗口静默关闭不发跳过",
      not mask1.isVisible() and mask2.isVisible() and mask_events == [])
mask2.dismiss_quietly()

resident = ResidentPetWindow(packs["bubu"], name="夏cc")
check("常驻桌宠名字标签显示夏cc",
      resident._name_label is not None
      and resident._name_label.text() == "夏cc")
resident.start()
QTest.qWait(60)
check("常驻桌宠可创建显示", resident.isVisible())
resident.set_pack(yier)  # 切换角色立即生效
QTest.qWait(60)
check("常驻桌宠可热切换角色", resident.isVisible())
resident.close()

# ================= 单实例调度（防重叠） =================
sed_win_events2: list = []
old_win = SedentaryPetWindow(yier, is_test=True)
old_win.confirmed.connect(lambda: sed_win_events2.append("confirmed"))
old_win.snoozed.connect(lambda: sed_win_events2.append("snoozed"))
old_win.start()
QTest.qWait(60)
old_win.dismiss_quietly()  # 主窗口调度：先静默销毁旧实例再创建新的
check("旧桌宠静默销毁且不发结果信号",
      not old_win.isVisible() and sed_win_events2 == [])
new_win = SedentaryPetWindow(yier, is_test=True)
new_win.start()
QTest.qWait(60)
check("新桌宠为唯一可见实例", new_win.isVisible() and not old_win.isVisible())
new_win.dismiss_quietly()

# ================= 托盘菜单顺序 =================
tray = TrayController(build_app_icon(), sed_agent, Stats(), manager.names())
actions = tray._menu.actions()
last = actions[-1]
check("托盘菜单最底部是“退出”", last.text() == "退出"
      and actions[-2].isSeparator())
texts = [a.text() for a in actions if not a.isSeparator() and a.text()]
check("其余菜单项齐全且顺序不变",
      texts[:3] == ["暂停计时", "立即休息", "重置计时"]
      and "切换角色" in texts and "设置..." in texts
      and "今日统计..." in texts)
tray._tray.hide()

check("统计持久化含站立数据", load_stats().stand_seconds >= 0)

# ================= 设置界面选项卡布局 =================
from settings_window import SettingsDialog  # noqa: E402
dlg = SettingsDialog(AppConfig(), manager.names())
check("设置对话框共 3 个选项卡且默认护眼提醒",
      dlg._tabs.count() == 3 and dlg._tabs.currentIndex() == 0
      and dlg._tabs.tabText(0) == "护眼提醒"
      and dlg._tabs.tabText(1) == "久坐提醒"
      and dlg._tabs.tabText(2) == "桌宠与通用")
dlg._work.setValue(15)
dlg._stand_char.setCurrentIndex(1)
roundtrip = dlg._collect()
check("选项卡内设置项装载与收集不受影响",
      roundtrip.work_minutes == 15
      and roundtrip.stand_character
      == (manager.names()[1][0] if len(manager.names()) > 1 else "yier")
      and roundtrip.pet_name == "夏cc")
dlg.close()
dlg.deleteLater()
d2 = AppConfig()
check("桌宠名字默认夏cc且位置字段默认-1",
      d2.pet_name == "夏cc" and d2.pet_home_x == -1 and d2.pet_home_y == -1)
check("空名字回退默认", AppConfig(pet_name="  ").sanitized().pet_name
      == "夏cc")

# ================= 站立/坐下独立角色 + m4a =================
cfgp = Path(os.environ["APPDATA"]) / "EyeGuard" / "config.json"
cfgp.write_text('{"pet_character": "bubu"}', encoding="utf-8")
migrated = load_config()
check("旧配置迁移：站立/坐下/护眼角色继承原形象",
      migrated.stand_character == "bubu" and migrated.sit_character == "bubu"
      and migrated.eye_character == "bubu")
check("默认站立/坐下角色为一二", AppConfig().stand_character == "yier"
      and AppConfig().sit_character == "yier")
dummy = Path(os.environ["APPDATA"]) / "dummy.m4a"
dummy.write_bytes(bytes(4) + b'ftypM4A ')
try:
    play_sound("file:" + str(dummy))  # MCI 失败自动走 Media Foundation
    check("m4a 音效导入播放不崩溃", True)
except Exception as exc:
    check("m4a 音效导入播放不崩溃", False)
dummy.unlink()

# ================= 提示音系统 =================
ensure_sound_files()
defaults = AppConfig()
check("三种默认提示音互不相同", len({defaults.eye_sound, defaults.stand_sound,
                                  defaults.sit_sound}) == 3)
check("提示音选项均合法", all(is_valid_sound(k) for k in
                            (defaults.eye_sound, defaults.stand_sound,
                             defaults.sit_sound)))
check("非法提示音回退默认", AppConfig(eye_sound="bogus").sanitized().eye_sound
      == "ding")
check("内置音效文件已生成", all((sound_dir() / f"{k}.wav").exists()
                            for k in ("ding", "pop", "sparkle", "chime",
                                      "bell")))
play_sound("none")
play_sound("ding")  # 异步播放，不阻塞
check("提示音可调用", True)
check("桌宠眨眼提醒方式合法", AppConfig(popup_mode=MODE_PET).sanitized()
      .popup_mode == MODE_PET)
check("MCI 出声验证存在（导入音效兜底）",
      hasattr(sound_player(), "_mci_audible")
      and hasattr(sound_player(), "_ps_play"))

# ================= 音量控制 =================
defaults2 = AppConfig()
check("音量默认 80（永不为 0）", defaults2.volume == 80)
check("音量夹紧 0-100", AppConfig(volume=150).sanitized().volume == 100
      and AppConfig(volume=-5).sanitized().volume == 0)
sp = sound_player()
sp.set_volume(30)
check("播放器音量实时生效", abs(sp._volume - 0.3) < 1e-6)
import io
import wave as wavemod
import array as arrmod

def _peak(wav_bytes: bytes) -> int:
    r = wavemod.open(io.BytesIO(wav_bytes), "rb")
    frames = r.readframes(r.getnframes())
    r.close()
    arr = arrmod.array("h")
    arr.frombytes(frames)
    return max((abs(v) for v in arr), default=0)

pop_data = sp._wav_bytes(sound_dir() / "pop.wav")
muted = sp._apply_volume(pop_data, 0.0)
loud = sp._apply_volume(pop_data, 1.0)
check("音量缩放正确作用于波形", _peak(muted) == 0
      and _peak(loud) > 0 and loud != muted)
sp.set_volume(80)

# ================= 音频单例播放器（修“时有时无”） =================
sp1 = sound_player()
sp2 = sound_player()
check("音频播放器为全局单例", sp1 is sp2 and isinstance(sp1, object))
for key in ("ding", "pop", "sparkle"):  # 连续快速触发 3 路（含打断重播）
    play_sound(key)
    QTest.qWait(60)
play_sound("ding")
QTest.qWait(120)
check("连续播放后 wav 缓冲常驻（不被 GC 回收）", len(sp1._wav_cache) >= 3
      and all(isinstance(v, bytes) and len(v) > 1000
              for v in sp1._wav_cache.values()))
missing_key = "file:" + str(Path(os.environ["APPDATA"]) / "不存在.mp3")
try:
    play_sound(missing_key)
    check("自定义音效缺失时回退默认不崩溃", True)
except Exception as exc:
    check("自定义音效缺失时回退默认不崩溃", False)
check("音频资源检查通过（启动自检）",
      (sound_dir() / "ding.wav").exists()
      and (sound_dir() / "pop.wav").exists()
      and (sound_dir() / "sparkle.wav").exists())
verify_audio_resources()

print()
if FAILURES:
    print(f"共 {len(FAILURES)} 项失败: {FAILURES}")
    sys.exit(1)
print("全部冒烟测试通过")
sys.exit(0)
